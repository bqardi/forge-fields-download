<?php

namespace ForgeFields;

class Checkbox_Field {
  public $meta_key;
  public $label;
  private $class;
  private $label_class;
  private $input_class;
  private $required;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->label = $args['label'];
    $this->class = $args['class'] ?? '';
    $this->label_class = $args['label_class'] ?? '';
    $this->input_class = $args['input_class'] ?? '';
    $this->required = $args['required'] ?? false;
  }

  public function sanitize_field($value) {
    return $value === '1' ? true : false;
  }

  public function render_field($value, $prefix = '') {
    $meta_key = $prefix === '' ? $this->meta_key : '['.$this->meta_key.']';
    $checked = !empty($value) ? 'checked' : '';
    ?>
    <label class="forge-field <?php echo $this->class; ?>" data-checkbox>
      <input
        type="checkbox"
        name="<?php echo $prefix.$meta_key; ?>"
        value="1"
        class="<?php echo $this->input_class . ($this->required ? ' required' : ''); ?>"
        data-meta-key="<?php echo $this->meta_key; ?>"
        <?php echo $checked; ?>
      />
      <span
        class="<?php echo $this->label_class; ?>"
      ><?php echo $this->label; ?></span>
    </label>
    <?php
  }
}