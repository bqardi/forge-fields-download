<?php

  /*
    Plugin Name: Forge Fields
    Plugin URI: https://bqardi.dk/forge-fields
    Description: A code-first WordPress plugin for defining dynamic fields and content using PHP classes and composition, designed for developers who value flexibility and control.
    Version: 1.0.0
    Author: Sune Seifert
    Author URI: https://bqardi.dk
    License: MIT
    License URI: https://opensource.org/licenses/MIT
    Text Domain: forge-fields
    Domain Path: /languages
  */

if (!defined('ABSPATH')) exit;

add_action('plugins_loaded', function() {
  require_once plugin_dir_path(__FILE__) . 'autoload.php';
});

/**
 * Enqueue Admin CSS and JS
 */
function enqueue_admin_custom_css($hook) {
  // Enqueue jQuery validation
  wp_enqueue_script('forge-fields-jquery-validate', plugin_dir_url(__FILE__) . 'js/jquery.validate.min.js', ['jquery'], '1.19.5', true);

  // Enqueue common admin styles and scripts
  wp_enqueue_style('forge-fields-css', plugin_dir_url(__FILE__) . 'app.css');
  wp_enqueue_script('forge-fields-js', plugin_dir_url(__FILE__) . 'app.js');
  
  if (is_admin()) {
    wp_enqueue_media();
  }
}
add_action('admin_enqueue_scripts', 'enqueue_admin_custom_css');

/****************************************
 ****** Frontend utility functions ******
 ****************************************/

/**
 * Custom Field Meta Box retrieval for frontend
 */
function forge_field($post_id, $meta_key) {
  $custom_field = get_post_meta($post_id, $meta_key, true);
  if (empty($custom_field)) return null;
  return $custom_field;
}

/**
 * Custom Field Module structural conversion for frontend
 */
function forge_module($array) {
  $module = [];
  foreach ($array as $index => $arr) {
    foreach ($arr as $name => $value) {
      $module[$index]['forge_field_module_name'] = $name;
      foreach ($value as $key => $val) {
        $module[$index][$key] = $val;
      }
    }
  }
  return $module;  
}

/****************************************
 ****** Backend utility functions *******
 ****************************************/

/**
 * Check if current page being edited is a frontpage
 */
function forge_is_front_page() {
  if (isset($_GET['post'])) {
    $post_id = intval($_GET['post']);
    return get_option('page_on_front') == $post_id;
  }
  return false;
}

/**
 * Check if the current page being edited has a specific slug.
 */
function forge_is_page($slug) {
  if (isset($_GET['post'])) {
    $post_id = intval($_GET['post']);
    $post = get_post($post_id);
    if ($post) {
      return $post->post_name === $slug; // Check the slug
    }
  }
  return false;
}

/**
 * Check if current page being edited is a specific post type
 */
function forge_is_post_type($post_type) {
  if (isset($_GET['post'])) {
    $post_id = intval($_GET['post']);
    return $post_type == get_post_type($post_id);
  }
  return false;
}

/**
 * Return the type of post/page being edited even custom posttypes
 */
function forge_get_post_type() {
  if (isset($_GET['post'])) {
    $post_id = intval($_GET['post']);
    return get_post_type($post_id);
  } elseif (isset($_GET['post_type'])) {
    return sanitize_text_field($_GET['post_type']);
  } elseif (isset($_POST['post_type'])) {
    return sanitize_text_field($_POST['post_type']);
  } elseif (isset($_POST['post_ID'])) {
    $post_id = intval($_POST['post_ID']);
    return get_post_type($post_id);
  }
  return null;
}
