<?php

  /*
    Plugin Name: Forge Fields
    Plugin URI: https://bqardi.dk/forge-fields
    Description: A code-first WordPress plugin for defining dynamic fields and content using PHP classes and composition, designed for developers who value flexibility and control.
    Version: 1.0.0
    Author: Sune Seifert
    Author URI: https://bqardi.dk
    License: MIT
    License URI: https://opensource.org/licenses/MIT
    Text Domain: forge-fields
    Domain Path: /languages
    Update URI: https://bqardi.github.io/forge-fields-download/
  */

if (!defined('ABSPATH')) exit;

add_action('plugins_loaded', function() {
  require_once plugin_dir_path(__FILE__) . 'autoload.php';
});

/**
 * Enqueue Admin CSS and JS
 */
function enqueue_admin_custom_css($hook) {
  // Enqueue jQuery validation
  wp_enqueue_script('forge-fields-jquery-validate', plugin_dir_url(__FILE__) . 'js/jquery.validate.min.js', ['jquery'], '1.19.5', true);

  // Enqueue common admin styles and scripts
  wp_enqueue_style('forge-fields-css', plugin_dir_url(__FILE__) . 'app.css');
  wp_enqueue_script('forge-fields-js', plugin_dir_url(__FILE__) . 'app.js');
  
  if (is_admin()) {
    wp_enqueue_media();
  }
}
add_action('admin_enqueue_scripts', 'enqueue_admin_custom_css');

/****************************************
 **** Automatic plugin update script ****
 ****************************************/

add_filter('plugins_api', 'forge_fields_plugin_update_info', 20, 3);
add_filter('site_transient_update_plugins', 'forge_fields_push_update');
add_filter('upgrader_post_install', 'forge_fields_after_update', 10, 3);
 
function forge_fields_plugin_update_info($res, $action, $args) {
  if ($action !== 'plugin_information') {
    return false;
  }

  if ($args->slug !== 'forge-fields') {
    return false;
  }

  $remote = wp_remote_get('https://bqardi.github.io/forge-fields-download/info.json');

  if (is_wp_error($remote)) {
    return false;
  }

  $remote = json_decode(wp_remote_retrieve_body($remote));

  $res = new stdClass();
  $res->name = $remote->name;
  $res->slug = $remote->slug;
  $res->version = $remote->version;
  $res->tested = $remote->tested;
  $res->requires = $remote->requires;
  $res->author = $remote->author;
  $res->author_profile = $remote->author_profile;
  $res->download_link = $remote->download_link;
  $res->trunk = $remote->download_link;
  $res->requires_php = $remote->requires_php;
  $res->last_updated = $remote->last_updated;
  $res->sections = array(
    'description' => $remote->sections->description,
    'installation' => $remote->sections->installation,
    'changelog' => $remote->sections->changelog,
  );

  return $res;
}

function forge_fields_push_update($transient) {
  if (empty($transient->checked)) {
    return $transient;
  }

  $remote = wp_remote_get('https://bqardi.github.io/forge-fields-download/info.json');

  if (is_wp_error($remote)) {
    return $transient;
  }

  $remote = json_decode(wp_remote_retrieve_body($remote));

  if ($remote && version_compare($transient->checked['forge-fields/forge-fields.php'], $remote->version, '<')) {
    $res = new stdClass();
    $res->slug = 'forge-fields';
    $res->plugin = 'forge-fields/forge-fields.php';
    $res->new_version = $remote->version;
    $res->tested = $remote->tested;
    $res->package = $remote->download_link;
    $transient->response[$res->plugin] = $res;
  }

  return $transient;
}
 
function forge_fields_after_update($response, $hook_extra, $result) {
  global $wp_filesystem;

  $install_directory = plugin_dir_path(__FILE__);

  $wp_filesystem->move($result['destination'], $install_directory);
  $result['destination'] = $install_directory;

  if (is_wp_error($result)) {
    return new WP_Error('plugin_install_failed', __('Plugin installation failed.', 'forge-fields'));
  }

  return $result;
}

/****************************************
 ****** Frontend utility functions ******
 ****************************************/

/**
 * Custom Field Meta Box retrieval for frontend
 */
function forge_field($post_id, $meta_key) {
  $custom_field = get_post_meta($post_id, $meta_key, true);
  if (empty($custom_field)) return null;
  return $custom_field;
}

/**
 * Custom Field Module structural conversion for frontend
 */
function forge_module($array) {
  $module = [];
  foreach ($array as $index => $arr) {
    foreach ($arr as $name => $value) {
      $module[$index]['forge_field_module_name'] = $name;
      foreach ($value as $key => $val) {
        $module[$index][$key] = $val;
      }
    }
  }
  return $module;  
}

/****************************************
 ****** Backend utility functions *******
 ****************************************/

/**
 * Check if current page being edited is a frontpage
 */
function forge_is_front_page() {
  if (isset($_GET['post'])) {
    $post_id = intval($_GET['post']);
    return get_option('page_on_front') == $post_id;
  }
  return false;
}

/**
 * Check if the current page being edited has a specific slug.
 */
function forge_is_page($slug) {
  if (isset($_GET['post'])) {
    $post_id = intval($_GET['post']);
    $post = get_post($post_id);
    if ($post) {
      return $post->post_name === $slug; // Check the slug
    }
  }
  return false;
}

/**
 * Check if current page being edited is a specific post type
 */
function forge_is_post_type($post_type) {
  if (isset($_GET['post'])) {
    $post_id = intval($_GET['post']);
    return $post_type == get_post_type($post_id);
  }
  return false;
}

/**
 * Return the type of post/page being edited even custom posttypes
 */
function forge_get_post_type() {
  if (isset($_GET['post'])) {
    $post_id = intval($_GET['post']);
    return get_post_type($post_id);
  } elseif (isset($_GET['post_type'])) {
    return sanitize_text_field($_GET['post_type']);
  } elseif (isset($_POST['post_type'])) {
    return sanitize_text_field($_POST['post_type']);
  } elseif (isset($_POST['post_ID'])) {
    $post_id = intval($_POST['post_ID']);
    return get_post_type($post_id);
  }
  return null;
}
