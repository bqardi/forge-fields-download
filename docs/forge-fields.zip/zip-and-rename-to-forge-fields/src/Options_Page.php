<?php

namespace ForgeFields;

class Options_Page {
  protected $option_name;
  protected $page_title;
  protected $menu_title;
  protected $capability;
  protected $menu_slug;
  protected $fields;

  public function __construct($args) {
    $this->option_name = $args['option_name'];
    $this->page_title = $args['page_title'];
    $this->menu_title = $args['menu_title'];
    $this->capability = $args['capability'];
    $this->menu_slug = $args['menu_slug'];
    $this->fields = $args['fields'];

    add_action('admin_menu', [$this, 'add_options_page']);
    add_action('admin_post_save_' . $this->option_name, [$this, 'save_options']);
  }

  public function add_options_page() {
    add_menu_page(
      $this->page_title,
      $this->menu_title,
      $this->capability,
      $this->menu_slug,
      [$this, 'render_options_page']
    );
  }

  public function render_options_page() {
    ?>
    <div class="wrap" data-options-page>
      <h1><?php echo esc_html($this->page_title); ?></h1>
      <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
        <input type="hidden" name="action" value="save_<?php echo $this->option_name; ?>">
        <?php wp_nonce_field($this->option_name . '_nonce', $this->option_name . '_nonce_field'); ?>
        <?php
        foreach ($this->fields as $field) {
          $options = get_option($this->option_name);
          $value = $options[$field->meta_key] ?? '';
          $field->render_field($value, $this->option_name);
        }
        submit_button();
        ?>
      </form>
    </div>
    <?php
  }

  public function save_options() {
    if (!isset($_POST[$this->option_name . '_nonce_field']) || !wp_verify_nonce($_POST[$this->option_name . '_nonce_field'], $this->option_name . '_nonce')) {
      return;
    }

    if (!current_user_can($this->capability)) {
      return;
    }

    $options = [];
    foreach ($this->fields as $field) {
      $options[$field->meta_key] = $field->sanitize_field($_POST[$this->option_name][$field->meta_key] ?? '');
    }

    update_option($this->option_name, $options);

    wp_redirect(add_query_arg('page', $this->menu_slug, admin_url('admin.php')));
    exit;
  }
}