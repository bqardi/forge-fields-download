<?php

namespace ForgeFields;

class Collection_Field {
  public $meta_key;
  public $fields;
  private $class;
  private $row_class;
  private $wrapper_class;
  private $content_class;
  private $add_button_text;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->fields = $args['fields'];
    $this->class = $args['class'] ?? '';
    $this->row_class = $args['row_class'] ?? '';
    $this->wrapper_class = $args['wrapper_class'] ?? '';
    $this->content_class = $args['content_class'] ?? '';
    $this->add_button_text = $args['add_button_text'] ?? 'Add Row';
  }

  public function sanitize_field($value) {
    $sanitized = [];
    foreach ($value as $index => $row) {
      $sanitized_row = [];
      foreach ($this->fields as $field) {
        $sanitized_row[$field->meta_key] = $field->sanitize_field($row[$field->meta_key] ?? '');
      }
      $sanitized[] = $sanitized_row;
    }
    return $sanitized;
  }

  private function render_delete_button() {
    ?>
      <button type="button" class="icon-button delete-button">
        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="currentColor"><path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/></svg>
      </button>
    <?php
  }

  public function render_field($values, $prefix = '') {
    $meta_key = $prefix === '' ? $this->meta_key : '['.$this->meta_key.']';
    $values = is_array($values) ? $values : [];
    ?>
      <div class="forge-field <?php echo $this->class; ?>" data-collection="<?php echo $prefix.$meta_key; ?>" data-row-index="<?php echo count($values);?>">
        <div
          id="collection-wrapper-<?php echo $prefix.$meta_key; ?>"
          class="collection-wrapper <?php echo $this->wrapper_class; ?>"
        >
          <p class="<?php echo count($values) > 0 ? 'hidden' : ''; ?>" data-no-content>Nothing here yet! Click "<?php echo $this->add_button_text; ?>" button below to add a new row</p>
          <?php foreach ($values as $index => $value) { ?>
            <div class="collection-row <?php echo $this->row_class; ?>">
              <?php $this->render_delete_button(); ?>
              <div class="collection-content <?php echo $this->content_class; ?>">
                <?php foreach ($this->fields as $field) {
                  $field->render_field($value[$field->meta_key] ?? '', $prefix.$meta_key.'['.$index.']');
                } ?>
              </div>
            </div>
          <?php } ?>
        </div>
        <button type="button" class="button" data-add-collection>
          <?php echo $this->add_button_text; ?>
        </button>
      </div>
      
      <template id="collection-content-template-<?php echo $prefix.$meta_key; ?>">
        <div class="collection-row <?php echo $this->row_class; ?>">
          <?php $this->render_delete_button(); ?>
          <div class="collection-content <?php echo $this->content_class; ?>">
            <?php foreach ($this->fields as $field) {
              $field->render_field('', $prefix.$meta_key.'[{{index}}]');
            } ?>
          </div>
        </div>
      </template>
    <?php
  }
}