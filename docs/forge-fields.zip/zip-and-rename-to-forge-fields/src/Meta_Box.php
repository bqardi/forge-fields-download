<?php

namespace ForgeFields;

class Meta_Box {
  protected $meta_key;
  protected $title;
  protected $post_types;
  protected $class;
  protected $fields;
  protected $remove_editor;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->title = $args['title'];
    $this->post_types = (array)$args['post_type'] ?? ['post', 'page'];
    $this->class = $args['class'] ?? '';
    $this->fields = $args['fields'] ?? [];
    $this->remove_editor = $args['remove_editor'] ?? false;

    add_action('add_meta_boxes', [$this, 'add_meta_box']);
    add_action('save_post', [$this, 'save_meta_box_data']);
    if ($this->remove_editor) {
      add_action('admin_init', [$this, 'remove_default_editor']);
    }
  }

  public function add_meta_box() {
    foreach ($this->post_types as $post_type) {
      add_meta_box(
        $this->meta_key,
        $this->title,
        [$this, 'render_meta_box'],
        $post_type,
        'normal',
        'high'
      );
    }
  }

  public function render_meta_box($post) {
    wp_nonce_field($this->meta_key . '_nonce', $this->meta_key . '_nonce_field');
    $values = get_post_meta($post->ID, $this->meta_key, true);
    $values = is_array($values) ? $values : [];
    echo '<div class="'.$this->class.'" data-meta-box>';
    foreach ($this->fields as $field) {
      $field->render_field($values[$field->meta_key] ?? '');
    }
    echo '</div>';
  }

  public function save_meta_box_data($post_id) {
    if (!isset($_POST[$this->meta_key . '_nonce_field']) || !wp_verify_nonce($_POST[$this->meta_key . '_nonce_field'], $this->meta_key . '_nonce')) {
      return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE || !current_user_can('edit_post', $post_id)) {
      return;
    }

    $meta_data = [];
    foreach ($this->fields as $field) {
      $meta_data[$field->meta_key] = $field->sanitize_field($_POST[$field->meta_key] ?? '');
    }

    update_post_meta($post_id, $this->meta_key, $meta_data);
  }

  public function remove_default_editor() {
    $post_id = isset($_GET['post']) ? $_GET['post'] : (isset($_POST['post_ID']) ? $_POST['post_ID'] : '');

    if ($post_id) {
      wp_enqueue_media();
      foreach ($this->post_types as $post_type) {
        remove_post_type_support($post_type, 'editor');
      }
    }
  }
}