<?php

namespace ForgeFields;

class Group_Field {
  public $meta_key;
  public $fields;
  private $class;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->fields = $args['fields'];
    $this->class = $args['class'] ?? '';
  }

  public function sanitize_field($value) {
    $meta_data = [];
    foreach ($this->fields as $field) {
      $meta_data[$field->meta_key] = $field->sanitize_field($value[$field->meta_key] ?? '');
    }
    return $meta_data;
  }

  public function render_field($value, $prefix = '') {
    $meta_key = $prefix === '' ? $this->meta_key : '['.$this->meta_key.']';
    $value = is_array($value) ? $value : [];
    ?>
      <div class="forge-field <?php echo esc_attr($this->class); ?>" data-group>
        <?php foreach ($this->fields as $field) {
          $field->render_field($value[$field->meta_key] ?? '', $prefix.$meta_key);
        } ?>
      </div>
    <?php
  }
}