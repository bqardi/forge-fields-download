<?php

namespace ForgeFields;

class Editor_Field {
  public $meta_key;
  public $label;
  private $class;
  private $editor_settings;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->label = $args['label'];
    $this->class = $args['class'] ?? '';
    $this->editor_settings = $args['editor_settings'] ?? [];
  }

  public function sanitize_field($value) {
    return wp_kses_post($value);
  }

  public function render_field($value, $prefix = '') {
    $meta_key = $prefix === '' ? $this->meta_key : '['.$this->meta_key.']';
    $field_id = uniqid('editor-');
    ?>
    <div class="forge-field <?php echo $this->class; ?>" data-editor>
      <label for="<?php echo $field_id; ?>"><?php echo esc_html($this->label); ?></label>
      <?php
      wp_editor(
        $value,
        $field_id,
        array_merge($this->editor_settings, ['textarea_name' => $prefix.$meta_key])
      );
      ?>
    </div>
    <?php
  }
}