<?php

namespace ForgeFields;

class Radio_Field {
  public $meta_key;
  public $label;
  private $class;
  private $container_class;
  private $label_class;
  private $options;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->label = $args['label'];
    $this->class = $args['class'] ?? '';
    $this->container_class = $args['container_class'] ?? '';
    $this->label_class = $args['label_class'] ?? '';
    $this->options = $args['options'];
  }

  public function sanitize_field($value) {
    return sanitize_text_field($value);
  }

  public function render_field($value, $prefix = '') {
    $meta_key = $prefix === '' ? $this->meta_key : '['.$this->meta_key.']';
    ?>
    <fieldset class="forge-field <?php echo $this->class; ?>" data-radio>
      <legend><?php echo esc_html($this->label); ?></legend>
      <div class="radio-group <?php echo $this->container_class; ?>">
        <?php foreach ($this->options as $option_value => $option_label) { ?>
          <label class="radio-label <?php echo $this->label_class; ?>">
            <input
              type="radio"
              name="<?php echo $prefix.$meta_key; ?>"
              value="<?php echo esc_attr($option_value); ?>"
              data-meta-key="<?php echo $this->meta_key; ?>"
              <?php checked($value, $option_value); ?>
            />
            <?php echo esc_html($option_label); ?>
          </label>
        <?php } ?>
      </div>
    </fieldset>
    <?php
  }

  public function sanitize($value) {
    return sanitize_text_field($value);
  }
}