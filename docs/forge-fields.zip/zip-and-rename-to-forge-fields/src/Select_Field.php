<?php

namespace ForgeFields;

class Select_Field {
  public $meta_key;
  public $label;
  private $class;
  private $label_class;
  private $select_class;
  private $options;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->label = $args['label'];
    $this->class = $args['class'] ?? '';
    $this->label_class = $args['label_class'] ?? '';
    $this->select_class = $args['select_class'] ?? '';
    $this->options = $args['options'];
  }

  public function sanitize_field($value) {
    return sanitize_text_field($value);
  }

  public function render_field($value, $prefix = '') {
    $meta_key = $prefix === '' ? $this->meta_key : '['.$this->meta_key.']';
    $field_id = uniqid('select-');
    ?>
      <div class="forge-field <?php echo $this->class; ?>" data-select>
        <label
          for="<?php echo $field_id; ?>"
          class="<?php echo $this->label_class; ?>"
        ><?php echo esc_html($this->label); ?></label>
        <select
          id="<?php echo $field_id; ?>"
          name="<?php echo $prefix.$meta_key; ?>"
          data-meta-key="<?php echo $this->meta_key; ?>"
          class="select-field <?php echo $this->select_class; ?>"
        >
          <?php foreach ($this->options as $option_value => $option_label) { ?>
            <option value="<?php echo esc_attr($option_value); ?>" <?php selected($value, $option_value); ?>>
              <?php echo esc_html($option_label); ?>
            </option>
          <?php } ?>
        </select>
      </div>
    <?php
  }

  public function sanitize($value) {
    return sanitize_text_field($value);
  }
}