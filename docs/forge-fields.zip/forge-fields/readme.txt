=== ForgeFields ===  
Contributors: bqardi  
Tags: fields, developer, dynamic fields, php classes, composition, custom fields  
Requires at least: 5.8  
Tested up to: 6.5  
Requires PHP: 7.4  
Stable tag: 1.0.0  
License: MIT  
License URI: https://opensource.org/licenses/MIT  

ForgeFields is a developer-first plugin for defining dynamic fields and content in WordPress using PHP classes and a composition-based approach.  

== Description ==  

**ForgeFields – Compose. Code. Create.**  

ForgeFields empowers developers to define custom fields and dynamic content **entirely in code** using PHP classes, embracing a **composition-based architecture** rather than traditional inheritance models.  

### Key Features:  
- **Code-First Approach:** Define fields directly in PHP, without relying on the WordPress admin UI.  
- **Composition Over Inheritance:** Build reusable, modular field structures with clean, maintainable code.  
- **Scalable & Flexible:** Adapt and grow your dynamic content structures with ease.  
- **Version Control Friendly:** Keep all your field definitions in your codebase and under version control.  
- **Developer-Oriented Workflow:** Focus on coding, not clicking.  

ForgeFields is perfect for developers who value flexibility, scalability, and the clarity of a **code-first workflow**.  

**Compose. Code. Create.** – with ForgeFields.  

== Installation ==  

1. Download the plugin ZIP file.  
2. Upload the folder to `/wp-content/plugins/` or install via the WordPress Plugin Installer.  
3. Activate the plugin through the 'Plugins' screen in WordPress.  
4. Start defining your fields using PHP classes.  

== Frequently Asked Questions ==  

= How do I define fields with ForgeFields? =  
Fields are defined using PHP classes directly in your theme or plugin files. Detailed documentation and examples are available on our website.  

= Is there an admin UI for managing fields? =  
No. ForgeFields is a **code-first plugin**, meaning everything is done in PHP for maximum flexibility and control.  

= Can I reuse field definitions across projects? =  
Absolutely! ForgeFields encourages reusable and modular field definitions, making it easy to share and maintain your code.  

== Screenshots ==  

1. **Example Field Definition in PHP** – A sample code snippet showing how to define a field using ForgeFields.  

== Changelog ==  

= 1.0.0 =  
* Initial release of ForgeFields.  
* Code-first dynamic fields with PHP classes.  
* Composition-based architecture for flexibility and scalability.  

== Upgrade Notice ==  

= 1.0.0 =  
Initial release. Safe to install on fresh setups.  

== License ==  

This plugin is licensed under the **MIT License**. See the [License URI](https://opensource.org/licenses/MIT) for details.  

== Links ==  
- [Website](https://your-website.com/forgefields)  
- [Documentation](https://your-website.com/forgefields/docs)  
- [Support](https://your-website.com/forgefields/support)  
- [GitHub Repository](https://github.com/yourusername/forgefields)  
