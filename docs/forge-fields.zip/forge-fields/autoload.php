<?php

spl_autoload_register(function ($class) {
  // Define the namespace prefix
  $prefix = 'ForgeFields\\';
  $base_dir = plugin_dir_path(__FILE__) . 'src/';
  $base_dir = str_replace('\\', '/', $base_dir);

  // Check if the class uses the namespace prefix
  $len = strlen($prefix);
  if (strncmp($prefix, $class, $len) !== 0) {
    // If the class does not use the prefix, move to the next registered autoloader
    return;
  }

  // Get the relative class name
  $relative_class = substr($class, $len);

  // Replace the namespace prefix with the base directory, replace namespace
  // separators with directory separators in the relative class name, append
  // with .php
  $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

  // If the file exists, require it
  if (file_exists($file)) {
    require $file;
  }
});
