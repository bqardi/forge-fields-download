<?php

namespace ForgeFields;

class Link_Field {
  public $meta_key;
  public $label;
  private $class;
  private $label_class;
  private static $template_added = false;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->label = $args['label'];
    $this->class = $args['class'] ?? '';
    $this->label_class = $args['label_class'] ?? '';

    // Add the template tag only once
    if (!self::$template_added) {
      add_action('admin_footer', [$this, 'add_html_once']);
      self::$template_added = true;
    }
  }

  public function add_html_once() {
    ?>
      <dialog id="link-modal" data-modal data-link-modal>
        <h2 class="title">Insert Link</h2>
        <form method="dialog" class="space-y-4">
          <div class="form-group">
            <label for="link-href" class="label">URL</label>
            <input
              id="link-href"
              type="url"
              class="input"
            />
          </div>
          <div class="form-group">
            <label for="link-title" class="label">Link Text</label>
            <input
              id="link-title"
              type="text"
              class="input"
            />
          </div>
          <div class="checkbox-group">
            <input id="link-target" type="checkbox" class="checkbox" />
            <label for="link-target" class="checkbox-label">Open link in a new tab</label>
          </div>
          <div class="list">
            <h3 class="label">Pages / Posts</h3>
            <div id="pages-list" class="list"></div>
          </div>
          <div class="button-group">
            <button
              value="cancel"
              type="button"
              class="button button-cancel"
              data-close
            >Cancel</button>
            <button
              value="submit"
              type="submit"
              class="button button-submit"
              data-close
            >Insert Link</button>
          </div>
        </form>
      </dialog>
    <?php
  }

  public function sanitize_field($value) {
    return $value;
  }

  public function render_field($value, $prefix = '') {
    $meta_key = $prefix === '' ? $this->meta_key : '['.$this->meta_key.']';
    $href = $value['href'] ?? '';
    $target = $value['target'] ?? '';
    $title = $value['title'] ?? '';
    ?>
    <div class="forge-field <?php echo $this->class; ?>" data-link="<?php echo $prefix.$meta_key; ?>">
      <div class="<?php echo $this->label_class; ?>">
        <?php echo esc_html($this->label); ?>
        <div class="link-field">
          <div class="link-field-content">
            <div class="link-field-header <?php echo $title ? 'link-field-header-gap' : ''; ?>">
              <span class="link-title" data-title><?php echo esc_html($title) ?: 'URL'; ?></span>
              <span class="link-target" data-target><?php echo esc_html($target === '_blank' ? 'External' : ''); ?></span>
            </div>
            <div class="link-url" data-url><?php echo esc_url($href); ?></div>
          </div>
          <input
            type="hidden"
            name="<?php echo $prefix.$meta_key; ?>[href]"
            value="<?php echo esc_attr($href); ?>"
            data-meta-key="<?php echo $this->meta_key; ?>[href]"
            data-url-input
          />
          <input
            type="hidden"
            name="<?php echo $prefix.$meta_key; ?>[title]"
            value="<?php echo esc_attr($title); ?>"
            data-meta-key="<?php echo $this->meta_key; ?>[title]"
            data-title-input
          />
          <input
            type="hidden"
            name="<?php echo $prefix.$meta_key; ?>[target]"
            value="<?php echo esc_attr($target); ?>"
            data-meta-key="<?php echo $this->meta_key; ?>[target]"
            data-target-input
          />
          <div class="link-buttons">
            <button data-meta-key="<?php echo $prefix.$meta_key; ?>" type="button" class="icon-button select-link-button">
              <svg class="select-link-icon" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M14.06,9L15,9.94L5.92,19H5V18.08L14.06,9M17.66,3C17.41,3 17.15,3.1 16.96,3.29L15.13,5.12L18.88,8.87L20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18.17,3.09 17.92,3 17.66,3M14.06,6.19L3,17.25V21H6.75L17.81,9.94L14.06,6.19Z"></path></svg>
            </button>
            <button type="button" class="icon-button remove-link-button <?php echo $href ? 'remove-link-button-visible' : 'remove-link-button-hidden'; ?>">
              <svg class="remove-link-icon" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19M8,9H16V19H8V9M15.5,4L14.5,3H9.5L8.5,4H5V6H19V4H15.5Z"></path></svg>
            </button>
          </div>
        </div>
      </div>
    </div>
    <?php
  }

  public function sanitize($value) {
    return array_map('sanitize_text_field', $value);
  }
}