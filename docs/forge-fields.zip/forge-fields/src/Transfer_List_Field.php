<?php

namespace ForgeFields;

class Transfer_List_Field {
  public $meta_key;
  public $label;
  private $class;
  private $input_class;
  private $post_types = [];
  private $items;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->label = $args['label'];
    $this->class = $args['class'] ?? '';
    $this->input_class = $args['input_class'] ?? '';
    $this->items = $args['items'] ?? [];
    $this->post_types = [];

    if (empty($this->items)) {
      add_action('wp_loaded', [$this, 'initialize_items']);
    }
  }

  public function sanitize_field($value) {
    return $value;
  }

  public function initialize_items() {
    $this->items = $this->get_items();
    $this->post_types = $this->get_post_types();
  }

  public function render_field($value, $prefix = '') {
    $meta_key = $prefix === '' ? $this->meta_key : '['.$this->meta_key.']';
    $value = is_array($value) ? $value : [];
    ?>
    <div class="forge-field <?php echo $this->class; ?>" data-transfer-list data-metakey="<?php echo $prefix.$meta_key; ?>">
      <label><?php echo esc_html($this->label); ?></label>
      <div class="search-container">
        <input type="text" class="search-field" placeholder="Search...">
        <select class="post-type-filter">
          <option value="">All Post Types</option>
          <?php foreach ($this->post_types as $post_type) { ?>
            <option value="<?php echo esc_attr($post_type); ?>"><?php echo esc_html($post_type); ?></option>
          <?php } ?>
        </select>
      </div>
      <div class="transfer-list-container">
        <div class="items">
          <h4 class="title">Available Items</h4>
          <ul class="list" data-list="available">
            <?php foreach ($this->items as $item) { ?>
              <li class="list-item" data-id="<?php echo esc_attr($item->ID); ?>" data-post-type="<?php echo esc_attr($item->post_type); ?>">
                <span class="list-item-text"><?php echo esc_html($item->post_title); ?></span>
              </li>
            <?php } ?>
          </ul>
        </div>
        <div class="items">
          <h4 class="title">Selected Items</h4>
          <ul class="list" data-list="selected">
            <?php foreach ($value as $item) { ?>
              <li class="list-item" data-id="<?php echo $item['id']; ?>" data-post-type="<?php echo get_post_type($item['id']); ?>">
              <span class="list-item-text"><?php echo get_the_title($item['id']); ?></span>
              </li>
              <input type="hidden" name="<?php echo $prefix.$meta_key; ?>[][id]" value="<?php echo esc_attr($item['id']); ?>">
            <?php } ?>
          </ul>
        </div>
      </div>
    </div>
    <?php
  }

  private function get_items() {
    $result = get_posts([
      'post_type' => 'any',
      'post_status' => 'publish',
      'posts_per_page' => -1,
    ]);
    return $result;
  }

  private function get_post_types() {
    $post_types = [];
    foreach ($this->items as $item) {
      $post_types[] = $item->post_type;
    }
    return array_unique($post_types);
  }
}