<?php

namespace ForgeFields;

class Color_Palette_Field {
  public $meta_key;
  public $label;
  private $class;
  private $palette;
  private $default_color;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->label = $args['label'];
    $this->class = $args['class'] ?? '';
    $this->palette = $args['palette'] ?? [];
  }

  public function sanitize_field($value) {
    return array_map('sanitize_hex_color', (array) $value);
  }

  /**
   * Calculate an accessible text color (black or white) for a given background color.
   *
   * @param string $backgroundColor Hex background color, e.g., '#RRGGBB' or 'RRGGBB'.
   * @return string Hex color code for text ('#000000' for black or '#FFFFFF' for white).
   */
  private function getAccessibleTextColor(string $backgroundColor): string {
    // Ensure the color starts with #
    $backgroundColor = ltrim($backgroundColor, '#');
    
    // Validate input
    if (!preg_match('/^[a-fA-F0-9]{6}$/', $backgroundColor)) {
        throw new InvalidArgumentException('Invalid background color. Use format #RRGGBB.');
    }
    
    // Extract RGB components
    list($r, $g, $b) = sscanf($backgroundColor, "%02x%02x%02x");
    
    // Calculate relative luminance
    $r = $r / 255 <= 0.03928 ? $r / 255 / 12.92 : pow(($r / 255 + 0.055) / 1.055, 2.4);
    $g = $g / 255 <= 0.03928 ? $g / 255 / 12.92 : pow(($g / 255 + 0.055) / 1.055, 2.4);
    $b = $b / 255 <= 0.03928 ? $b / 255 / 12.92 : pow(($b / 255 + 0.055) / 1.055, 2.4);
    
    $luminance = 0.2126 * $r + 0.7152 * $g + 0.0722 * $b;
    
    // Use white text if the luminance is low (dark background), otherwise use black text
    return ($luminance > 0.179) ? '#000000' : '#FFFFFF';
  }


  public function render_field($value, $prefix = '') {
    $meta_key = $prefix === '' ? $this->meta_key : '['.$this->meta_key.']';
    $field_id = uniqid('color-palette-');
    $value = is_array($value) ? $value : [];
    ?>
      <div class="forge-field <?php echo $this->class; ?>" data-color-palette>
        <label for="<?php echo $field_id; ?>"><?php echo esc_html($this->label); ?></label>
        <div class="color-palette">
          <?php foreach ($this->palette as $label => $color) { ?>
            <label
                class="color-toggle"
                style="background-color: <?php echo $color; ?>; color: <?php echo $this->getAccessibleTextColor($color); ?>"
              >
              <input
                type="checkbox"
                name="<?php echo $prefix.$meta_key; ?>[]"
                value="<?php echo $color; ?>"
                class="color-input"
                data-meta-key="<?php echo $this->meta_key; ?>"
                <?php checked(in_array($color, $value)); ?>
              />
              <span class="color-label"><?php echo $label; ?></span>
            </label>
          <?php } ?>
        </div>
      </div>
    <?php
  }
}