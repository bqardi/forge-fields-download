<?php

namespace ForgeFields;

class Checkbox_Field {
  public $meta_key;
  public $label;
  private $class;
  private $label_class;
  private $input_class;
  private $required;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->label = $args['label'];
    $this->class = $args['class'] ?? '';
    $this->label_class = $args['label_class'] ?? '';
    $this->input_class = $args['input_class'] ?? '';
    $this->required = $args['required'] ?? false;
  }

  public function sanitize_field($value) {
    return $value;
  }

  public function render_field($value, $prefix = '') {
    $meta_key = $prefix === '' ? $this->meta_key : '['.$this->meta_key.']';
    $checked = $value === 'yes' ? 'checked' : '';
    ?>
    <label class="forge-field <?php echo $this->class; ?>" data-checkbox>
      <input
        type="hidden"
        name="<?php echo $prefix.$meta_key; ?>"
        value="<?php echo $value; ?>"
        data-meta-key="<?php echo $this->meta_key; ?>"
      />
      <input
        type="checkbox"
        class="checkbox sr-only"
        <?php echo $checked; ?>
        data-custom-checkbox
      />
      <div class="custom-checkbox">
        <svg fill="currentColor" height="20px" width="20px" viewBox="0 -960 960 960" xmlns="http://www.w3.org/2000/svg"><path d="M382-240 154-468l57-57 171 171 367-367 57 57-424 424Z"/></svg>
      </div>
      <span class="<?php echo $this->label_class; ?>"><?php echo $this->label; ?></span>
    </label>
    <?php
  }
}