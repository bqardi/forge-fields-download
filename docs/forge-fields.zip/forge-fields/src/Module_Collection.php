<?php

namespace ForgeFields;

class Module_Collection {
  public $meta_key;
  public $modules;
  private $class;
  private $add_button_text;
  private $preview_images;
  private static $template_added = false;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->modules = $args['modules'];
    $this->class = $args['class'] ?? '';
    $this->add_button_text = $args['add_button_text'] ?? 'Add Module';
    $this->preview_images = $args['preview_images'] ?? [];

    // Add the template tag only once
    if (!self::$template_added) {
      add_action('admin_footer', [$this, 'add_html_once']);
      self::$template_added = true;
    }
  }

  public function sanitize_field($value) {
    $sanitized = [];
    foreach ($value as $index => $module) {
      $sanitized_module = [];
      foreach ($this->modules as $module_type => $module_fields) {
        if (isset($module[$module_type])) {
          foreach ($module_fields as $field) {
            $sanitized_module[$module_type][$field->meta_key] = $field->sanitize_field($module[$module_type][$field->meta_key] ?? '');
          }
        }
      }
      $sanitized[] = $sanitized_module;
    }
    return $sanitized;
  }

  private function render_delete_button() {
    ?>
      <button type="button" class="icon-button delete-button" data-delete>
        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="currentColor"><path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/></svg>
      </button>
    <?php
  }

  private function render_module_label($module_type) {
    $label = ucfirst(str_replace('_', ' ', $module_type));
    ?>
      <h2 class="module-label"><?php echo $label; ?></h2>
    <?php
  }

  public function render_field($values, $prefix = '') {
    $meta_key = $prefix === '' ? $this->meta_key : '['.$this->meta_key.']';
    $values = is_array($values) ? $values : [];
    ?>
      <div class="<?php echo $this->class; ?>" data-module-collection="<?php echo $prefix.$meta_key; ?>" data-row-index="<?php echo count($values);?>">
        <div
          id="module-collection-wrapper-<?php echo $prefix.$meta_key; ?>"
          class="module-collection-wrapper"
        >
          <p class="<?php echo count($values) > 0 ? 'hidden' : ''; ?>" data-no-content>Nothing here yet! Click "<?php echo $this->add_button_text; ?>" button below to add a new module</p>
          <?php foreach ($values as $index => $value) { ?>
            <div class="module-row">
              <div class="module-delete-button"><?php $this->render_delete_button(); ?></div>
              <div class="module-content">
                <?php foreach ($this->modules as $module_type => $module_fields) {
                  if (isset($value[$module_type])) { ?>
                    <?php $this->render_module_label($module_type); ?>
                    <div data-module-type="<?php echo $module_type; ?>">
                      <?php foreach ($module_fields as $field) {
                        $field->render_field($value[$module_type][$field->meta_key] ?? '', $prefix.$meta_key.'['.$index.']['.$module_type.']');
                      } ?>
                    </div>
                  <?php }
                } ?>
              </div>
            </div>
          <?php } ?>
        </div>
        <div class="module-collection-modal" data-module-modal>
          <button type="button" class="module-collection-modal-button button" data-add>
            <?php echo $this->add_button_text; ?>
          </button>
        </div>
      </div>
      
      <template id="module-content-template-<?php echo $prefix.$meta_key; ?>">
        <div class="module-row">
          <?php $this->render_delete_button(); ?>
          <div class="module-content" data-module-content>
          </div>
        </div>
      </template>

      <?php foreach ($this->modules as $module_type => $module_fields) { ?>
        <template id="module-template-<?php echo $module_type; ?>-<?php echo $prefix.$meta_key; ?>">
          <div data-module-type="<?php echo $module_type; ?>">
            <?php foreach ($module_fields as $field) {
              $field->render_field('', $prefix.$meta_key.'[{{index}}]['.$module_type.']');
            } ?>
          </div>
        </template>
      <?php } ?>
    <?php
  }

  public function add_html_once() {
    ?>
      <dialog id="modules-modal" data-modal data-modules-modal>
        <img
          src=""
          alt=""
          class="preview-image hidden"
          data-image
        >
        <h2 class="title">Insert Module</h2>
        <form method="dialog" class="space-y-4">
          <div class="list">
            <h3 class="label">Modules</h3>
            <div class="list" data-list>
              <?php foreach ($this->modules as $module_type => $module_fields) { ?>
                <button
                  value="<?php echo $module_type; ?>"
                  type="submit"
                  class="module-type"
                  data-preview-image="<?php echo $this->preview_images[$module_type] ?? ''; ?>"
                  data-close
                ><?php echo ucfirst(str_replace('_', ' ', $module_type)); ?></button>
              <?php } ?>
            </div>
          </div>
          <div class="button-group">
            <button
              value="cancel"
              type="button"
              class="button button-cancel"
              data-close
            >Cancel</button>
          </div>
        </form>
      </dialog>
    <?php
  }
}