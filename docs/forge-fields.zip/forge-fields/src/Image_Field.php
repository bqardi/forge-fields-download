<?php

namespace ForgeFields;

class Image_Field {
  public $meta_key;
  public $label;
  private $class;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->label = $args['label'];
    $this->class = $args['class'] ?? '';
  }

  public function sanitize_field($value) {
    return $value;
  }

  public function render_field($value, $prefix = '') {
    $meta_key = $prefix === '' ? $this->meta_key : '['.$this->meta_key.']';
    $url = $value['url'] ?? '';
    ?>
      <div class="forge-field <?php echo $this->class; ?>" data-image="<?php echo $this->meta_key; ?>">
        <span class="image-label"><?php echo esc_html($this->label); ?></span>
        <div class="image-preview-wrapper" style="margin-bottom: 10px;">
          <div class="image-preview" style="margin-bottom: 10px;">
            <?php if ($url) { ?>
              <img src="<?php echo esc_url($url); ?>" class="image" />
            <?php } else { ?>
              <p>No image selected</p>
            <?php } ?>
          </div>
        
          <div class="image-buttons has-image">
            <button type="button" class="icon-button upload-image-button" aria-label="Edit image">
              <svg class="icon" width="20" height="20" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M14.06,9L15,9.94L5.92,19H5V18.08L14.06,9M17.66,3C17.41,3 17.15,3.1 16.96,3.29L15.13,5.12L18.88,8.87L20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18.17,3.09 17.92,3 17.66,3M14.06,6.19L3,17.25V21H6.75L17.81,9.94L14.06,6.19Z"></path></svg>
            </button>
            <button type="button" class="icon-button remove-image-button" aria-label="Remove image" style="display: <?php echo $url ? 'inline-block' : 'none'; ?>;">
              <svg class="icon" width="20" height="20" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19M8,9H16V19H8V9M15.5,4L14.5,3H9.5L8.5,4H5V6H19V4H15.5Z"></path></svg>
            </button>
          </div>
        </div>
        <div
          data-hidden-inputs
          data-prefix="<?php echo $prefix; ?>"
          data-meta-key="<?php echo $meta_key; ?>"
        >
          <?php
            if (is_array($value)) {
              foreach ($value as $key => $val) {
                ?>
                  <input
                    type="hidden"
                    name="<?php echo $prefix.$meta_key; ?>[<?php echo $key; ?>]"
                    value="<?php echo esc_attr($val); ?>"
                    data-meta-key="<?php echo $this->meta_key; ?>[<?php echo $key; ?>]"
                    class="image-<?php echo $key; ?>"
                  />
                <?php
              }
            } ?>
        </div>
      </div>
    <?php
  }

  public function sanitize($value) {
    return array_map('sanitize_text_field', $value);
  }
}