<?php

namespace ForgeFields;

class Range_Slider_Field {
  public $meta_key;
  public $label;
  private $class;
  private $min;
  private $max;
  private $step;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->label = $args['label'];
    $this->class = $args['class'] ?? '';
    $this->min = $args['min'] ?? 0;
    $this->max = $args['max'] ?? 100;
    $this->step = $args['step'] ?? 1;
  }

  public function sanitize_field($value) {
    return array_map('intval', $value);
  }

  public function render_field($value, $prefix = '') {
    $meta_key = $prefix === '' ? $this->meta_key : '['.$this->meta_key.']';
    $value_min = $value['min'] ?? $this->min;
    $value_max = $value['max'] ?? $this->max;
    ?>
    <div class="forge-field <?php echo $this->class; ?>" data-range-slider>
      <label id="range-slider-label"><?php echo esc_html($this->label); ?></label>
      <div class="slider-container">
        <div class="active-track" data-active-track></div>
        <input
          type="range"
          class="range-input"
          name="<?php echo $prefix.$meta_key; ?>[min]"
          min="<?php echo esc_attr($this->min); ?>"
          max="<?php echo esc_attr($this->max); ?>"
          step="<?php echo esc_attr($this->step); ?>"
          value="<?php echo esc_attr($value_min); ?>"
          aria-label="Minimum value"
          data-range-min
        />
        <input
          type="range"
          class="range-input range-input-max"
          name="<?php echo $prefix.$meta_key; ?>[max]"
          min="<?php echo esc_attr($this->min); ?>"
          max="<?php echo esc_attr($this->max); ?>"
          step="<?php echo esc_attr($this->step); ?>"
          value="<?php echo esc_attr($value_max); ?>"
          aria-label="Maximum value"
          data-range-max
        />
      </div>
      <div class="range-values">
        <span>Min: <output data-output-min><?php echo esc_html($value_min); ?></output></span>
        <span>Max: <output data-output-max><?php echo esc_html($value_max); ?></output></span>
      </div>
    </div>
    <?php
  }
}