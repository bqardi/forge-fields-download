<?php

namespace ForgeFields;

class Text_Field {
  public $meta_key;
  public $label;
  private $type;
  private $class;
  private $label_class;
  private $input_class;
  private $required;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->label = $args['label'];
    $this->type = $args['type'] ?? 'text';
    $this->class = $args['class'] ?? '';
    $this->label_class = $args['label_class'] ?? '';
    $this->input_class = $args['input_class'] ?? '';
    $this->required = $args['required'] ?? false;
  }

  public function sanitize_field($value) {
    return sanitize_text_field($value);
  }

  public function render_field($value, $prefix = '') {
    $meta_key = $prefix === '' ? $this->meta_key : '['.$this->meta_key.']';
    $field_id = uniqid('text-');
    ?>
      <label class="forge-field <?php echo $this->class; ?>" data-text>
        <span
          class="<?php echo $this->label_class; ?>"
        ><?php echo esc_html($this->label); ?></span>
        <input
          type="<?php echo $this->type; ?>"
          name="<?php echo $prefix.$meta_key; ?>"
          value="<?php echo esc_attr($value); ?>"
          data-meta-key="<?php echo $this->meta_key; ?>"
          class="<?php echo $this->input_class . ($this->required ? ' required' : ''); ?>"
        />
      </label>
    <?php
  }
}