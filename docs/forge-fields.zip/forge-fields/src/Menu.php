<?php

namespace ForgeFields;

class Menu {
  protected $meta_key;
  protected $title;
  protected $fields;
  protected $menus;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->title = $args['title'];
    $this->fields = $args['fields'];
    $this->menus = $args['menus'] ?? [];

    add_action('wp_nav_menu_item_custom_fields', [$this, 'render_menu_item_fields'], 10, 4);
    add_action('wp_update_nav_menu_item', [$this, 'save_menu_item_fields'], 10, 3);
    add_filter('manage_nav-menus_columns', [$this, 'add_menu_columns'], 10, 1);
  }

  public function render_menu_item_fields($item_id, $item, $depth, $args) {
    global $nav_menu_selected_id;
    
    $menu_locations = get_nav_menu_locations();
    $menu_location = '';

    foreach ($menu_locations as $location => $id) {
      if ($id === $nav_menu_selected_id) {
        $menu_location = $location;
        break;
      }
    }

    // Check if the current menu is in the specified menus
    if (!empty($this->menus) && !in_array($menu_location, $this->menus)) {
      return;
    }

    wp_nonce_field($this->meta_key . '_nonce', $this->meta_key . '_nonce_field');
    $values = get_post_meta($item_id, $this->meta_key, true);
    $values = is_array($values) ? $values : [];
    echo '<div class="menu-item-custom-fields" data-menu>';
    foreach ($this->fields as $field) {
      echo '<div class="field-'.$field->meta_key.'">';
      $field->render_field($values[$field->meta_key] ?? '', $this->meta_key.'['.$item_id.']');
      echo '</div>';
    }
    echo '</div>';
  }

  public function save_menu_item_fields($menu_id, $menu_item_db_id, $args) {
    // Check if the current menu is in the specified menus
    if (!empty($this->menus) && !in_array($args->menu->slug, $this->menus)) {
      return;
    }

    if (!isset($_POST[$this->meta_key . '_nonce_field']) || !wp_verify_nonce($_POST[$this->meta_key . '_nonce_field'], $this->meta_key . '_nonce')) {
      return;
    }

    $meta_data = [];
    foreach ($this->fields as $field) {
      $meta_data[$field->meta_key] = $field->sanitize_field($_POST[$this->meta_key][$menu_item_db_id][$field->meta_key] ?? '');
    }

    update_post_meta($menu_item_db_id, $this->meta_key, $meta_data);
  }

  public function add_menu_columns($columns) {
    $columns[$this->meta_key] = $this->title;
    return $columns;
  }
}