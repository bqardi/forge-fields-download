<?php

namespace ForgeFields;

class Taxonomy {
  protected $meta_key;
  protected $title;
  protected $taxonomy;
  protected $fields;

  public function __construct($args) {
    $this->meta_key = $args['id'];
    $this->title = $args['title'];
    $this->taxonomy = $args['taxonomy'];
    $this->fields = $args['fields'];

    add_action("{$this->taxonomy}_add_form_fields", [$this, 'add_taxonomy_fields']);
    add_action("{$this->taxonomy}_edit_form_fields", [$this, 'edit_taxonomy_fields']);
    add_action("created_{$this->taxonomy}", [$this, 'save_taxonomy_fields']);
    add_action("edited_{$this->taxonomy}", [$this, 'save_taxonomy_fields']);
  }

  public function add_taxonomy_fields($taxonomy) {
    echo '<div class="form-field" data-taxonomy-fields>';
    foreach ($this->fields as $field) {
      echo '<div class="field-'.$field->meta_key.'" data-taxonomy-field>';
      $field->render_field('', $this->meta_key.'[new_term]');
      echo '</div>';
    }
    echo '</div>';
  }

  public function edit_taxonomy_fields($term) {
    $values = get_term_meta($term->term_id, $this->meta_key, true);
    $values = is_array($values) ? $values : [];
    echo '<tr class="form-field">';
    foreach ($this->fields as $field) {
      echo '<th scope="row" valign="top"><label for="'.$field->meta_key.'">'.$field->field_label.'</label></th>';
      echo '<td>';
      $field->render_field($values[$field->meta_key] ?? '', $this->meta_key.'['.$term->term_id.']');
      echo '</td>';
    }
    echo '</tr>';
  }

  public function save_taxonomy_fields($term_id) {
    if (isset($_POST[$this->meta_key])) {
      $meta_data = [];
      foreach ($this->fields as $field) {
        if (isset($_POST[$this->meta_key]['new_term'][$field->meta_key])) {
          $meta_data[$field->meta_key] = $field->sanitize_field($_POST[$this->meta_key]['new_term'][$field->meta_key]);
        } elseif (isset($_POST[$this->meta_key][$term_id][$field->meta_key])) {
          $meta_data[$field->meta_key] = $field->sanitize_field($_POST[$this->meta_key][$term_id][$field->meta_key]);
        }
      }
      update_term_meta($term_id, $this->meta_key, $meta_data);
    }
  }
}